# Chargement --------

library(tidyverse)
library(readxl)
library(lubridate)
library(lemon)
library(ggthemes)
library(khroma)
library(ggh4x)
library(GGally)
library(scales)
library(ggrepel)

bd <- read_excel("bandes_dessinees_tintin.xlsx")

bd$date <- str_c(bd$annee, "-", bd$mois, "-01") %>% ymd()
bd$date <- str_c("01/", bd$mois, "/", bd$annee) %>% dmy()


# Nombre de BD distribuées par mois --------

# Sys.setlocale("LC_TIME", "English") # sous windows. 
# Sous Mac : essayer en_US ou fr_FR à la place de "English"/"French"
# Sys.setlocale("LC_TIME", "French")

ggplot(bd) +
  aes(x = date, weight = bd_distribuees, fill = type_etablissement) +
  geom_bar() +
  geom_text(
    mapping = aes(label = after_stat(count), fill = NULL),
    data = bd %>% filter(bd$mois %% 2 == 1),
    stat = "count", size = 2.75, vjust = 0, nudge_y = 200
  ) +
  labs(x = "", y = "", fill = "") +
  ggtitle("Nombre de bandes dessinées\ndistribuées chaque mois") +
  facet_rep_grid(
    rows = vars(pays), repeat.tick.labels = TRUE, 
    switch = "y"
  ) +
  scale_fill_bright() +
  scale_x_date(
    date_breaks = "3 months", date_labels = "%b\n%Y",
    date_minor_breaks = "1 month",
    guide = guide_axis_minor()
  ) +
  scale_y_continuous(limits = c(0, 6500)) +
  theme_clean() +
  theme(
    legend.position = "bottom",
    strip.placement = "outside",
    strip.text.y = element_text(face = "bold"),
    plot.title.position = 'plot',
    plot.title = element_text(hjust = .5)
  )

# Evolution du ratio BD / eleve

nb_moy <- ggplot(bd) +
  aes(
    x = date, y = bd_distribuees / eleves_rencontres, 
    weight = eleves_rencontres,
    colour = type_etablissement,
    ymin = map2_dbl(after_stat(numerator), after_stat(denominator), ~ poisson.test(.x, .y) %>% pluck("conf.int", 1)),
    ymax = map2_dbl(after_stat(numerator), after_stat(denominator), ~ poisson.test(.x, .y) %>% pluck("conf.int", 2))
  ) +
  geom_hline(yintercept = 1) +
  geom_ribbon(
    stat = "weighted_mean",
    mapping = aes(fill = type_etablissement, colour = NULL),
    alpha = .15, show.legend = FALSE
  ) +
  geom_line(stat = "weighted_mean", size = 1) +
  geom_point(stat = "weighted_mean") +
  geom_text_repel(
    data = bd %>% filter(date == max(date)),
    stat = "weighted_mean",
    mapping = aes(label = number(after_stat(y), accuracy = .1)),
    show.legend = FALSE,
    hjust = 0, nudge_x = 10, fontface = "bold",
    direction = "y", force = 2
  ) +
  ggtitle("Nombre moyen de BD remises par élève") +
  labs(x = "", y = "", fill = "", colour = "") +
  expand_limits(y = 0, x = max(bd$date) + months(1)) +
  scale_x_date(
    date_breaks = "3 months", date_labels = "%b\n%Y",
    date_minor_breaks = "1 month",
    guide = guide_axis_minor()
  ) +
  scale_color_bright() +
  scale_fill_bright() +
  theme_clean() +
  theme(legend.position = "bottom") +
  facet_rep_grid(cols = vars(pays), repeat.tick.labels = TRUE)

plot(nb_moy)

# Combiner plusieurs graphiques

p_bordurie <- ggplot(bd %>% filter(pays == "Bordurie")) +
  aes(x = date, weight = bd_distribuees, fill = type_etablissement) +
  geom_bar() +
  labs(x = "", y = "", fill = "") +
  scale_fill_bright() +
  scale_x_date(
    date_breaks = "3 months", date_labels = "%b\n%Y",
    date_minor_breaks = "1 month",
    guide = guide_axis_minor()
  ) +
  scale_y_continuous(limits = c(0, 6500)) +
  theme_clean() +
  theme(
    legend.position = "bottom",
  )
plot(p_bordurie)

p_syldavie <- ggplot(bd %>% filter(pays == "Syldavie")) +
  aes(x = date, weight = bd_distribuees, fill = type_etablissement) +
  geom_bar() +
  labs(x = "", y = "", fill = "") +
  scale_fill_bright() +
  scale_x_date(
    date_breaks = "3 months", date_labels = "%b\n%Y",
    date_minor_breaks = "1 month",
    guide = guide_axis_minor()
  ) +
  scale_y_continuous(limits = c(0, 6500)) +
  theme_clean() +
  theme(
    legend.position = "bottom",
  )
plot(p_syldavie)

library(cowplot)

plot_grid(p_bordurie, p_syldavie)

plot_grid(p_bordurie, p_syldavie, labels = c("Bordurie", "Syldavie"))

plot_grid(p_bordurie + ggtitle("Bordurie"), p_syldavie + ggtitle("Syldavie"))

plot_grid(
  p_bordurie + ggtitle("Bordurie"), 
  p_syldavie + ggtitle("Syldavie"),
  ncol = 1
)


plot_grid(
  p_bordurie + ggtitle("Bordurie"), 
  nb_moy,
  ncol = 1
)


plot_grid(
  p_bordurie, 
  p_syldavie + ylab("Axe Y"),
  ncol = 1, align = "hv"
)

plot_grid(
  p_bordurie + theme(legend.position = "none"),
  p_syldavie + theme(legend.position = "none"),
  get_legend(p_bordurie)
)
