# Script pour un graphique sur les connaissances

library(tidyverse)
library(labelled)
library(scales)
library(GGally)
library(khroma)
library(extrafont)
load("connaissances.RData")

conn <- quest %>%
  select(id, starts_with("conn_")) %>%
  pivot_longer(
    cols = starts_with("conn_"),
    names_to = "question",
    values_to = "reponse"
  )

conn$reponse <- conn$reponse %>%
  fct_explicit_na("NSP") %>%
  fct_relevel("non", "NSP", "oui") %>%
  fct_recode("ne sait pas / manquant" = "NSP")

conn$etiquette <- conn$question %>%
  fct_recode(
    "R est disponible seulement pour Windows" = "conn_a",
    "R possède un puissant moteur graphique" = "conn_b",
    "Il est possible de réaliser des modèles mixtes avec R" = "conn_c",
    "Le package 'foreign' est le seul permettant d'importer des fichiers de données SPSS" = "conn_d",
    "Il n'est pas possible de produire un rapport PDF avec R" = "conn_e",
    "R peut gérer des données d'enquêtes avec un plan d'échantillonnage complexe" = "conn_f",
    "R est utilisée par des scientifiques de toutes disciplines, y compris des sciences sociales" = "conn_g"
  )

conn$etiquette <- conn$etiquette %>%
  fct_reorder(conn$reponse == "oui", .fun = "sum")


f <- function(x) {
  res <- scales::percent(x, accuracy = 1)
  res[x < .05] <- scales::percent(x[x < .05], accuracy = 1, suffix = "")
  res[x < .01] <- ""
  res
}

conn$correcte <- conn$question %>%
  fct_recode(
    "bonne réponse : non" = "conn_a",
    "bonne réponse : oui" = "conn_b",
    "bonne réponse : oui" = "conn_c",
    "bonne réponse : non" = "conn_d",
    "bonne réponse : non" = "conn_e",
    "bonne réponse : oui" = "conn_f",
    "bonne réponse : oui" = "conn_g"
  ) %>%
  fct_rev()

p <- ggplot(conn) +
  aes(
    x = etiquette, fill = reponse, 
    label = f(after_stat(prop)), 
    by = etiquette
  ) +
  geom_bar(position = "fill", width = .66) +
  geom_text(
    position = position_fill(.5), stat = "prop",
    colour = "white", fontface = "bold", size = 3.5,
    family = "Arial Narrow"
  ) +
  scale_x_discrete(labels = label_wrap(50)) +
  scale_y_continuous(labels = label_percent(), expand = expansion(0, 0)) +
  scale_fill_manual(values = c("#AA3377", "#BBBBBB", "#4477AA")) +
  labs(
    x = "", y = "", fill = "",
    caption = "Enquête réalisée auprès de 500 étudiants"
  ) +
  guides(fill = guide_legend(reverse = TRUE)) +
  theme_minimal(base_family = "Arial Narrow") +
  theme(
    legend.position = "bottom",
    panel.grid = element_blank(),
    axis.text.x = element_blank(),
    plot.title.position = "plot",
    plot.caption.position = "plot",
    plot.caption = element_text(face = "italic", hjust = 0),
    plot.margin = margin(10, 10, 10, 10)
  ) +
  coord_flip() +
  facet_grid(rows = vars(correcte), scales = "free", space = "free") +
  ggtitle(
    "CONNAISSANCES SUR R",
    subtitle = "Pour chacune des affirmations suivantes, diriez-vous qu'elle est correcte ?"
  )

p

ggsave("connaissances.png", plot = p, width = 16, height = 10, units = "cm", scale = 1.25)
